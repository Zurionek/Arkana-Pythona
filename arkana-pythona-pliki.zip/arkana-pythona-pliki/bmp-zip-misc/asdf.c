#include <stdio.h>
int main() { puts("Good night!"); return 0; }
