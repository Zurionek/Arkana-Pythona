1. Make a new virtual environment and run `pip install -r requirements.txt`
2. Run `pyinstaller hello.py`
