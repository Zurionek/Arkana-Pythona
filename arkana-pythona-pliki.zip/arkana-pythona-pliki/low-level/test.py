import random
def give_str():
  return random.choice([
    "ala", "ma", "kota",
  ])

def pront(s):
  output = []
  for ch in s:
    c = ord(ch)
    if c in range(ord('a'), ord('z')+1):
      c += 119945
    elif ord('A') <= c <= ord('Z'):
      c += 119951
    output.append(chr(c))
    output.append(' ')
  print(''.join(output))

def hello(s={}):
  print(s)

import types
my_hello = types.FunctionType(
  hello.__code__,
  {
    "print": pront
  },
  name="my_hello",
  argdefs=("not hello world",)
)
my_hello()



