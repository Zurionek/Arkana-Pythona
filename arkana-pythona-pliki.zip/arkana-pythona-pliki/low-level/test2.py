def ret():
  return "hello world"

def asdf(x: print([chr(x) for x in range(32,126)])="asdf"):
  #print(asdf.__annotations__["x"])
  pass

asdf()
asdf()
asdf()
asdf()

