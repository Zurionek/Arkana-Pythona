
clean = open("hello_clean.bmp", "rb").read()
gynvael = open("hello_gynvael.zip", "rb").read()
world = open("hello_world.zip", "rb").read()

with open("hello_world.bmp", "wb") as f:
  f.write(clean[:-len(gynvael)])
  f.write(gynvael)
  f.write(world)
