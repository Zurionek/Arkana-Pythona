#!/usr/bin/env python3
import sys

MARKER = "# FORBIDDEN:"

if len(sys.argv) != 2:
  sys.exit("usage: checker.py <file.py>")

with open(sys.argv[1]) as f:
  code = f.read()

idx = code.find("\n")
first_line = code[:idx]
code = code[idx:]

if not first_line.startswith(MARKER):
  sys.exit(
      "ERROR: First line must start with '# FORBIDDEN: ' "
      "followed by list of chars"
  )
forbidden_chars = first_line[len(MARKER):].strip()
print("Forbidden chars:", forbidden_chars)


error = False
for ch in forbidden_chars:
  if ch in code:
    error = True
    print(f"ERROR: Forbidden char {ch} was found in code!")
if error:
  sys.exit()

c = compile(code, "code.py", "exec")
exec(c)
