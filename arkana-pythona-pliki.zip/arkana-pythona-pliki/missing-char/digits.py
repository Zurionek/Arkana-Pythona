# FORBIDDEN: 0123456789

a = len("A")
b = a+a+a+a+a+a+a+a+a+a
c = b**(a+a)
d = b**(a+a+a)

print(d + c + c + b + b + b + a+ a+ a+ a)
