# FORBIDDEN: =

# for x in ["Hello World!"]: pass

def y(a):
  return "Hello World!"

#@y
#def x():
  #...


print(x)
