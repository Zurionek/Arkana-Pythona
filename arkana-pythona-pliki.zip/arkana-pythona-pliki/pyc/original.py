a = "ala"

def print_stuff():
  b = "ma"
  c = "kota"
  print(' '.join([a,b,c]))

print_stuff()
