# Gynvael's manual RE
a = 'ala'

def print_stuff():
  b = 'ma'
  c = 'kota'
  print(' '.join([a, b, c]))

print_stuff()


# Chat GPT 5.0 (based on dis.dis() dump)
a = 'ala'
def print_stuff():
  b = 'ma'
  c = 'kota'
  print(' '.join([a, b, c]))
print_stuff()
