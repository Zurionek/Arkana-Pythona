



# > dis.dis(c)
#   0           0 RESUME                   0

#   1           2 LOAD_CONST               0 ('ala')
#               4 STORE_NAME               0 (a)
a = 'ala'

#   3           6 LOAD_CONST               1 (<code object>)
#               8 MAKE_FUNCTION            0
#              10 STORE_NAME               1 (print_stuff)
#print_stuff = <function object>
def print_stuff():

# Disassembly of <code object print_stuff at 0x7f7eab3d6450, file "asdf.py", line 3>:
#   3           0 RESUME                   0

#   4           2 LOAD_CONST               1 ('ma')
#               4 STORE_FAST               0 (b)
  b = 'ma'

#   5           6 LOAD_CONST               2 ('kota')
#               8 STORE_FAST               1 (c)
  c = 'kota'

#   6          10 LOAD_GLOBAL              1 (NULL + print)
#              20 LOAD_CONST               3 (' ')
#              22 LOAD_ATTR                3 (NULL|self + join)
#              42 LOAD_GLOBAL              4 (a)
#              52 LOAD_FAST                0 (b)
#              54 LOAD_FAST                1 (c)
#              56 BUILD_LIST               3
#              58 CALL                     1
#              66 CALL                     1
#              74 POP_TOP
  print(' '.join([a, b, c]))
#              76 RETURN_CONST             0 (None)
  #return None




#   8          12 PUSH_NULL
#              14 LOAD_NAME                1 (print_stuff)
#              16 CALL                     0
#              24 POP_TOP
print_stuff()  # (None)

#              26 RETURN_CONST             2 (None)
#return None

