from flask import Flask, request, jsonify, send_file
import math
import json

app = Flask(__name__)

@app.route('/')
@app.route('/index.html')
def index():
    return send_file('index.html')

@app.route('/api/calculate', methods=['POST'])
def calculate():
    try:
        data = request.get_json()
        if not data or 'expression' not in data:
            return jsonify({'error': 'Missing expression in request'}), 400

        expression = data['expression']
        # Evaluate the mathematical expression safely
        result = eval(expression, {"__builtins__": {}}, {"math": math})

        return jsonify({'result': str(result)})
    except Exception as e:
        return jsonify({'error': str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
