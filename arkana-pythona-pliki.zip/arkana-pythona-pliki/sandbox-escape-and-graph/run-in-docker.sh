#!/bin/bash
docker build -t calc .
docker run --rm -p 5000:5000 calc
